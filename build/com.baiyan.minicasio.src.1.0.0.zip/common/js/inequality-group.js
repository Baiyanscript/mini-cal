// inequality-group.js - 不等式組求解(支援一次/二次不等式聯立求交集)

function tokenize(s) {
  var tokens = []
  var i = 0
  while (i < s.length) {
    var ch = s.charAt(i)
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '(' || ch === ')') {
      if (ch === '-' && (tokens.length === 0 || tokens[tokens.length - 1] === '(' || tokens[tokens.length - 1] === '+' || tokens[tokens.length - 1] === '-' || tokens[tokens.length - 1] === '*' || tokens[tokens.length - 1] === '/')) {
        var num = '-'
        i++
        while (i < s.length && ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || s.charAt(i) === '.')) {
          num += s.charAt(i)
          i++
        }
        tokens.push(num)
        continue
      }
      tokens.push(ch)
      i++
    } else if (ch === '^') {
      tokens.push(ch)
      i++
    } else if ((ch >= '0' && ch <= '9') || ch === '.') {
      var num2 = ''
      while (i < s.length && ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || s.charAt(i) === '.')) {
        num2 += s.charAt(i)
        i++
      }
      tokens.push(num2)
    } else if (ch === 'x') {
      tokens.push(ch)
      i++
    } else {
      i++
    }
  }
  return tokens
}

function multiplyPoly(c1, c2) {
  var result = {}
  for (var k1 in c1) {
    if (!c1.hasOwnProperty(k1)) continue
    for (var k2 in c2) {
      if (!c2.hasOwnProperty(k2)) continue
      var v = c1[k1] * c2[k2]
      var deg1 = k1 === 'const' ? 0 : parseInt(k1.substring(1))
      var deg2 = k2 === 'const' ? 0 : parseInt(k2.substring(1))
      var newDeg = deg1 + deg2
      var newKey = newDeg === 0 ? 'const' : 'x' + newDeg
      result[newKey] = (result[newKey] || 0) + v
    }
  }
  return result
}

function dividePoly(c1, c2) {
  var keys = Object.keys(c2)
  if (keys.length === 1 && keys[0] === 'const') {
    var divisor = c2['const']
    if (divisor === 0) return c1
    var result = {}
    for (var k in c1) {
      if (c1.hasOwnProperty(k)) {
        result[k] = c1[k] / divisor
      }
    }
    return result
  }
  return c1
}

function parseFactor(tokens, pos) {
  if (pos >= tokens.length) return { coeffs: {}, pos: pos }
  var t = tokens[pos]

  if (t === '(') {
    var exprRes = parseExprRD(tokens, pos + 1)
    var endPos = exprRes.pos
    if (endPos < tokens.length && tokens[endPos] === ')') {
      endPos++
    }
    return { coeffs: exprRes.coeffs, pos: endPos }
  }

  if (t === 'x') {
    var coeff = 1
    if (pos + 1 < tokens.length && tokens[pos + 1] === '^') {
      var power = parseInt(tokens[pos + 2])
      if (!isNaN(power) && power >= 1) {
        var key = 'x' + power
        var obj = {}
        obj[key] = coeff
        return { coeffs: obj, pos: pos + 3 }
      }
    }
    var obj2 = {}
    obj2['x1'] = coeff
    return { coeffs: obj2, pos: pos + 1 }
  }

  var num = parseFloat(t)
  if (!isNaN(num)) {
    if (pos + 1 < tokens.length && tokens[pos + 1] === 'x') {
      var varCoeff = num
      if (pos + 2 < tokens.length && tokens[pos + 2] === '^') {
        var varPower = parseInt(tokens[pos + 3])
        if (!isNaN(varPower) && varPower >= 1) {
          var obj3 = {}
          obj3['x' + varPower] = varCoeff
          return { coeffs: obj3, pos: pos + 4 }
        }
      }
      var obj4 = {}
      obj4['x1'] = varCoeff
      return { coeffs: obj4, pos: pos + 2 }
    }
    return { coeffs: { 'const': num }, pos: pos + 1 }
  }

  return { coeffs: {}, pos: pos + 1 }
}

function parseTerm(tokens, pos) {
  var res = parseFactor(tokens, pos)
  var coeffs = res.coeffs
  var i = res.pos
  while (i < tokens.length) {
    if (tokens[i] === '*' || tokens[i] === '/') {
      var op = tokens[i]
      var factorRes = parseFactor(tokens, i + 1)
      if (op === '*') {
        coeffs = multiplyPoly(coeffs, factorRes.coeffs)
      } else {
        coeffs = dividePoly(coeffs, factorRes.coeffs)
      }
      i = factorRes.pos
    } else if (tokens[i] === '(' || tokens[i] === 'x') {
      var factorRes2 = parseFactor(tokens, i)
      coeffs = multiplyPoly(coeffs, factorRes2.coeffs)
      i = factorRes2.pos
    } else {
      break
    }
  }
  return { coeffs: coeffs, pos: i }
}

function parseExprRD(tokens, pos) {
  var sign = 1
  if (pos < tokens.length && tokens[pos] === '-') {
    sign = -1
    pos++
  } else if (pos < tokens.length && tokens[pos] === '+') {
    pos++
  }
  var res = parseTerm(tokens, pos)
  var coeffs = res.coeffs
  if (sign === -1) {
    for (var key in coeffs) {
      if (coeffs.hasOwnProperty(key)) {
        coeffs[key] = -coeffs[key]
      }
    }
  }
  var i = res.pos
  while (i < tokens.length && (tokens[i] === '+' || tokens[i] === '-')) {
    var op = tokens[i]
    var termRes = parseTerm(tokens, i + 1)
    for (var key2 in termRes.coeffs) {
      var val = termRes.coeffs[key2]
      if (op === '-') val = -val
      coeffs[key2] = (coeffs[key2] || 0) + val
    }
    i = termRes.pos
  }
  return { coeffs: coeffs, pos: i }
}

function parseExpr(s) {
  if (s.length === 0) return { x2: 0, x1: 0, 'const': 0 }
  s = s.replace(/×/g, '*').replace(/÷/g, '/')
  var tokens = tokenize(s)
  var result = parseExprRD(tokens, 0)
  var coeffs = result.coeffs
  if (!coeffs.x2) coeffs.x2 = 0
  if (!coeffs.x1) coeffs.x1 = 0
  if (!coeffs['const']) coeffs['const'] = 0
  return coeffs
}

function splitInequality(expr) {
  var ops = ['≥', '≤', '>', '<']
  var i = -1
  var op = ''
  for (var k = 0; k < ops.length; k++) {
    var idx = expr.indexOf(ops[k])
    if (idx !== -1) {
      if (i === -1 || idx < i) {
        i = idx
        op = ops[k]
      }
    }
  }
  if (i === -1) return null
  return {
    left: expr.substring(0, i),
    op: op,
    right: expr.substring(i + op.length)
  }
}

function solveIneqRange(leftStr, op, rightStr) {
  var left = parseExpr(leftStr)
  var right = parseExpr(rightStr)

  var a = (left.x2 || 0) - (right.x2 || 0)
  var b = (left.x1 || 0) - (right.x1 || 0)
  var c = (left['const'] || 0) - (right['const'] || 0)

  var eps = 1e-9
  if (Math.abs(a) < eps) {
    if (Math.abs(b) < eps) {
      var holds = false
      if (op === '>') holds = c > 0
      else if (op === '<') holds = c < 0
      else if (op === '≥') holds = c >= 0
      else if (op === '≤') holds = c <= 0
      return holds ? { type: 'all' } : { type: 'none' }
    }

    var val = -c / b
    var actualOp = op
    if (b < 0) {
      if (op === '>') actualOp = '<'
      else if (op === '<') actualOp = '>'
      else if (op === '≥') actualOp = '≤'
      else if (op === '≤') actualOp = '≥'
    }

    if (actualOp === '>') return { type: 'gt', val: val }
    if (actualOp === '<') return { type: 'lt', val: val }
    if (actualOp === '≥') return { type: 'ge', val: val }
    if (actualOp === '≤') return { type: 'le', val: val }
    return { type: 'none' }
  }

  var disc = b * b - 4 * a * c
  var isStrict = (op === '>' || op === '<')

  if (disc < -eps) {
    var alwaysPositive = (a > 0)
    var wantPositive = (op === '>' || op === '≥')
    if (alwaysPositive === wantPositive) {
      return { type: 'all' }
    } else {
      return { type: 'none' }
    }
  }

  if (Math.abs(disc) <= eps) {
    var x0 = -b / (2 * a)
    var parabolaUp = (a > 0)

    if (parabolaUp) {
      if (op === '>') return { type: 'union', r1: { type: 'lt', val: x0 }, r2: { type: 'gt', val: x0 } }
      if (op === '<') return { type: 'none' }
      if (op === '≥') return { type: 'all' }
      if (op === '≤') return { type: 'single', val: x0 }
    } else {
      if (op === '<') return { type: 'union', r1: { type: 'lt', val: x0 }, r2: { type: 'gt', val: x0 } }
      if (op === '>') return { type: 'none' }
      if (op === '≤') return { type: 'all' }
      if (op === '≥') return { type: 'single', val: x0 }
    }
    return { type: 'none' }
  }

  var sqrtDisc = Math.sqrt(disc)
  var x1 = (-b - sqrtDisc) / (2 * a)
  var x2 = (-b + sqrtDisc) / (2 * a)
  if (x1 > x2) {
    var tmp = x1
    x1 = x2
    x2 = tmp
  }

  var aPositive = (a > 0)
  var wantMiddle = false
  if (aPositive) {
    if (op === '<' || op === '≤') wantMiddle = true
  } else {
    if (op === '>' || op === '≥') wantMiddle = true
  }

  if (wantMiddle) {
    return { type: 'middle', lo: x1, loStrict: isStrict, hi: x2, hiStrict: isStrict }
  } else {
    return { type: 'union', r1: { type: isStrict ? 'lt' : 'le', val: x1 }, r2: { type: isStrict ? 'gt' : 'ge', val: x2 } }
  }
}

function rangeToIntervals(r) {
  if (r.type === 'all') return [{ lo: null, loStrict: false, hi: null, hiStrict: false }]
  if (r.type === 'none') return []
  if (r.type === 'single') return [{ lo: r.val, loStrict: false, hi: r.val, hiStrict: false }]
  if (r.type === 'gt') return [{ lo: r.val, loStrict: true, hi: null, hiStrict: false }]
  if (r.type === 'lt') return [{ lo: null, loStrict: false, hi: r.val, hiStrict: true }]
  if (r.type === 'ge') return [{ lo: r.val, loStrict: false, hi: null, hiStrict: false }]
  if (r.type === 'le') return [{ lo: null, loStrict: false, hi: r.val, hiStrict: false }]
  if (r.type === 'middle') return [{ lo: r.lo, loStrict: r.loStrict, hi: r.hi, hiStrict: r.hiStrict }]
  if (r.type === 'union') {
    return rangeToIntervals(r.r1).concat(rangeToIntervals(r.r2))
  }
  return []
}

function intersectIntervals(a, b) {
  var lo, loStrict, hi, hiStrict

  if (a.lo === null && b.lo === null) { lo = null; loStrict = false }
  else if (a.lo === null) { lo = b.lo; loStrict = b.loStrict }
  else if (b.lo === null) { lo = a.lo; loStrict = a.loStrict }
  else if (a.lo > b.lo) { lo = a.lo; loStrict = a.loStrict }
  else if (b.lo > a.lo) { lo = b.lo; loStrict = b.loStrict }
  else { lo = a.lo; loStrict = a.loStrict || b.loStrict }

  if (a.hi === null && b.hi === null) { hi = null; hiStrict = false }
  else if (a.hi === null) { hi = b.hi; hiStrict = b.hiStrict }
  else if (b.hi === null) { hi = a.hi; hiStrict = a.hiStrict }
  else if (a.hi < b.hi) { hi = a.hi; hiStrict = a.hiStrict }
  else if (b.hi < a.hi) { hi = b.hi; hiStrict = b.hiStrict }
  else { hi = a.hi; hiStrict = a.hiStrict || b.hiStrict }

  if (lo !== null && hi !== null) {
    if (lo > hi) return null
    if (lo === hi && (loStrict || hiStrict)) return null
  }

  return { lo: lo, loStrict: loStrict, hi: hi, hiStrict: hiStrict }
}

function intervalToRange(iv) {
  if (iv.lo === null && iv.hi === null) return { type: 'all' }
  if (iv.lo === null) {
    return iv.hiStrict ? { type: 'lt', val: iv.hi } : { type: 'le', val: iv.hi }
  }
  if (iv.hi === null) {
    return iv.loStrict ? { type: 'gt', val: iv.lo } : { type: 'ge', val: iv.lo }
  }
  if (iv.lo === iv.hi) {
    if (iv.loStrict || iv.hiStrict) return { type: 'none' }
    return { type: 'single', val: iv.lo }
  }
  return { type: 'middle', lo: iv.lo, loStrict: iv.loStrict, hi: iv.hi, hiStrict: iv.hiStrict }
}

function intervalsToRange(intervals) {
  if (intervals.length === 0) return { type: 'none' }
  if (intervals.length === 1) return intervalToRange(intervals[0])

  intervals.sort(function (a, b) {
    if (a.lo === null && b.lo === null) return 0
    if (a.lo === null) return -1
    if (b.lo === null) return 1
    if (a.lo < b.lo) return -1
    if (a.lo > b.lo) return 1
    return 0
  })

  var ranges = []
  for (var i = 0; i < intervals.length; i++) {
    var r = intervalToRange(intervals[i])
    if (r.type !== 'none') ranges.push(r)
  }

  if (ranges.length === 0) return { type: 'none' }
  if (ranges.length === 1) return ranges[0]

  var result = ranges[0]
  for (var j = 1; j < ranges.length; j++) {
    result = { type: 'union', r1: result, r2: ranges[j] }
  }
  return result
}

function intersectRanges(ranges) {
  if (ranges.length === 0) return { type: 'all' }

  for (var i = 0; i < ranges.length; i++) {
    if (ranges[i].type === 'none') return { type: 'none' }
  }

  var intervals = rangeToIntervals(ranges[0])

  for (var j = 1; j < ranges.length; j++) {
    var nextIntervals = rangeToIntervals(ranges[j])
    var result = []
    for (var a = 0; a < intervals.length; a++) {
      for (var b = 0; b < nextIntervals.length; b++) {
        var inter = intersectIntervals(intervals[a], nextIntervals[b])
        if (inter) result.push(inter)
      }
    }
    intervals = result
    if (intervals.length === 0) return { type: 'none' }
  }

  return intervalsToRange(intervals)
}

function formatNum(n) {
  var rounded = Math.round(n * 100000) / 100000
  if (Math.abs(rounded - Math.round(rounded)) < 0.000001) {
    return String(Math.round(rounded))
  }
  var str = String(rounded)
  if (str.length > 10) {
    str = rounded.toExponential(4)
  }
  return str
}

// rangeToStr 回傳語言無關的代碼標記,由呼叫端(頁面)依語言翻譯 ALL_REAL / NO_SOLUTION / ||OR||
function rangeToStr(r) {
  if (r.type === 'all') return 'ALL_REAL'
  if (r.type === 'none') return 'NO_SOLUTION'
  if (r.type === 'single') return 'x=' + formatNum(r.val)
  if (r.type === 'gt') return 'x > ' + formatNum(r.val)
  if (r.type === 'lt') return 'x < ' + formatNum(r.val)
  if (r.type === 'ge') return 'x ≥ ' + formatNum(r.val)
  if (r.type === 'le') return 'x ≤ ' + formatNum(r.val)
  if (r.type === 'middle') {
    var loBracket = r.loStrict ? '(' : '['
    var hiBracket = r.hiStrict ? ')' : ']'
    return loBracket + formatNum(r.lo) + ', ' + formatNum(r.hi) + hiBracket
  }
  if (r.type === 'union') {
    return rangeToStr(r.r1) + ' ||OR|| ' + rangeToStr(r.r2)
  }
  return 'NO_SOLUTION'
}

// 主入口: 輸入形如 "2x+3>7;x<6" 的不等式組(用;分隔),回傳結果字串(可能含ALL_REAL/NO_SOLUTION/||OR||代碼標記)
// 拋出的Error.message可能是: EMPTY / TRANSCENDENTAL / FORMAT_ERROR / PARSE_ERROR
export function solveInequalityGroup(rawExpr) {
  var expr = rawExpr.replace(/\s/g, '').replace(/−/g, '-')
  if (expr.length === 0) {
    throw new Error('EMPTY')
  }

  if (/log\(|ln\(|lg\(|sin\(|cos\(|tan\(|e\^|π/.test(expr)) {
    throw new Error('TRANSCENDENTAL')
  }

  var parts = expr.split(';')
  var inequalities = []
  for (var i = 0; i < parts.length; i++) {
    if (parts[i].length > 0) inequalities.push(parts[i])
  }

  if (inequalities.length === 0) {
    throw new Error('EMPTY')
  }

  var ranges = []
  for (var k = 0; k < inequalities.length; k++) {
    var parsed = splitInequality(inequalities[k])
    if (!parsed) {
      throw new Error('FORMAT_ERROR')
    }
    try {
      var range = solveIneqRange(parsed.left, parsed.op, parsed.right)
      ranges.push(range)
    } catch (e) {
      throw new Error('PARSE_ERROR')
    }
  }

  var result = intersectRanges(ranges)
  return rangeToStr(result)
}
