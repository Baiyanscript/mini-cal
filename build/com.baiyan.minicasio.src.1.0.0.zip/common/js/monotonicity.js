// monotonicity.js - 函式單調性分析
import { isPolynomialExpr, getDerivCoeffs, evalNumerical, formatNum } from './derivative'

function evaluatePolynomial(coeffs, x) {
  var val = 0
  for (var key in coeffs) {
    if (key === 'const') {
      val += coeffs[key]
    } else {
      var deg = parseInt(key.substring(1))
      val += coeffs[key] * Math.pow(x, deg)
    }
  }
  return val
}

// 回傳語言無關的區間描述陣列: [{from, to, inc: true/false}], from/to可能是'-∞'/'+∞'字串或數字字串
// 或拋出 Error('CONSTANT') 表示函式為常數
function findMonotonicityPoly(deriv) {
  var nonZero = []
  for (var k in deriv) {
    if (Math.abs(deriv[k]) > 1e-9) nonZero.push({ key: k, val: deriv[k] })
  }
  if (nonZero.length === 0) {
    throw new Error('CONSTANT')
  }

  var maxDeg = 0
  for (var i = 0; i < nonZero.length; i++) {
    var d = nonZero[i].key === 'const' ? 0 : parseInt(nonZero[i].key.substring(1))
    if (d > maxDeg) maxDeg = d
  }

  var roots = []
  if (maxDeg === 0) {
    var c = deriv.const || 0
    return [{ from: '-∞', to: '+∞', inc: c > 0 }]
  } else if (maxDeg === 1) {
    var a = deriv.x1 || 0
    var b = deriv.const || 0
    if (Math.abs(a) > 1e-9) roots.push(-b / a)
  } else if (maxDeg === 2) {
    var a2 = deriv.x2 || 0
    var b2 = deriv.x1 || 0
    var c2 = deriv.const || 0
    var disc = b2 * b2 - 4 * a2 * c2
    var eps = 1e-9
    if (disc > eps) {
      var r1 = (-b2 - Math.sqrt(disc)) / (2 * a2)
      var r2 = (-b2 + Math.sqrt(disc)) / (2 * a2)
      if (r1 > r2) { var tmp = r1; r1 = r2; r2 = tmp }
      roots.push(r1, r2)
    } else if (Math.abs(disc) <= eps) {
      roots.push(-b2 / (2 * a2))
    } else {
      return [{ from: '-∞', to: '+∞', inc: a2 > 0 }]
    }
  } else {
    return null // 三次以上,呼叫端改用抽樣法
  }

  var parts = []
  var startLabel = '-∞'
  for (i = 0; i <= roots.length; i++) {
    var testX
    if (i === 0) testX = roots[0] - 1
    else if (i === roots.length) testX = roots[roots.length - 1] + 1
    else testX = (roots[i - 1] + roots[i]) / 2

    var derivVal = evaluatePolynomial(deriv, testX)
    var isInc = derivVal > 0
    var endLabel = (i === roots.length) ? '+∞' : formatNum(roots[i])
    parts.push({ from: startLabel, to: endLabel, inc: isInc })
    startLabel = endLabel
  }
  return parts
}

function sampleMonotonicity(expr) {
  var samples = [-5, -3, -1, 0, 1, 3, 5]
  var parts = []
  var startX = '-∞'
  var prevSign = 0

  for (var i = 0; i < samples.length; i++) {
    var d = evalNumerical(expr, samples[i])
    var sign = d > 0 ? 1 : -1
    if (prevSign !== 0 && sign !== prevSign) {
      var label = formatNum(samples[i])
      parts.push({ from: startX, to: label, inc: prevSign > 0 })
      startX = label
    }
    prevSign = sign
  }
  parts.push({ from: startX, to: '+∞', inc: prevSign > 0 })
  return parts
}

// 主入口: 回傳區間陣列, 拋出 Error('EMPTY') / Error('CONSTANT') / Error('PARSE_ERROR')
export function solveMonotonicity(rawExpr) {
  var expr = rawExpr.replace(/\s/g, '')
  if (expr.length === 0) {
    throw new Error('EMPTY')
  }
  try {
    if (isPolynomialExpr(expr)) {
      var deriv = getDerivCoeffs(expr)
      var result = findMonotonicityPoly(deriv)
      if (result === null) {
        return sampleMonotonicity(expr)
      }
      return result
    } else {
      return sampleMonotonicity(expr)
    }
  } catch (e) {
    if (e.message === 'CONSTANT') throw e
    throw new Error('PARSE_ERROR')
  }
}
