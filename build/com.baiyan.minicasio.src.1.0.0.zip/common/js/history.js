// history.js - 計算機歷史記錄
import storage from '@system.storage'

var HISTORY_KEY = 'calc_history'
var MAX_ENTRIES = 100

export function loadHistory(callback) {
  storage.get({
    key: HISTORY_KEY,
    success: function (data) {
      var list = []
      if (data) {
        try {
          list = JSON.parse(data)
        } catch (e) {
          list = []
        }
      }
      callback(list)
    },
    fail: function () {
      callback([])
    }
  })
}

function saveHistory(list) {
  storage.set({
    key: HISTORY_KEY,
    value: JSON.stringify(list)
  })
}

export function addEntry(expression, result) {
  loadHistory(function (list) {
    list.unshift({ expression: expression, result: result })
    if (list.length > MAX_ENTRIES) {
      list = list.slice(0, MAX_ENTRIES)
    }
    saveHistory(list)
  })
}

export function deleteEntry(index, callback) {
  loadHistory(function (list) {
    list.splice(index, 1)
    saveHistory(list)
    if (callback) callback(list)
  })
}

export function clearHistory(callback) {
  storage.delete({
    key: HISTORY_KEY,
    success: function () {
      if (callback) callback()
    },
    fail: function () {
      if (callback) callback()
    }
  })
}
