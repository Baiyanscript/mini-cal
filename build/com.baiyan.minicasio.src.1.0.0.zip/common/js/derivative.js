// derivative.js - 求導數(多項式用符號微分,其餘用數值微分)
import { evaluate } from './math-utils'

function isPolynomial(expr) {
  var s = expr.replace(/\s/g, '')
  for (var i = 0; i < s.length; i++) {
    var c = s.charAt(i)
    if (!((c >= '0' && c <= '9') || c === 'x' || c === '+' || c === '-' || c === '*' || c === '/' || c === '^' || c === '(' || c === ')' || c === '.')) {
      return false
    }
  }
  return true
}

function tokenize(s) {
  var tokens = []
  var i = 0
  while (i < s.length) {
    var ch = s.charAt(i)
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '(' || ch === ')' || ch === '^') {
      if (ch === '-' && (tokens.length === 0 || tokens[tokens.length - 1] === '(' || ['+', '-', '*', '/'].indexOf(tokens[tokens.length - 1]) !== -1)) {
        var num = '-'
        i++
        while (i < s.length && ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || s.charAt(i) === '.')) {
          num += s.charAt(i)
          i++
        }
        tokens.push(num)
        continue
      }
      tokens.push(ch)
      i++
    } else if ((ch >= '0' && ch <= '9') || ch === '.') {
      var num2 = ''
      while (i < s.length && ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || s.charAt(i) === '.')) {
        num2 += s.charAt(i)
        i++
      }
      tokens.push(num2)
    } else if (ch === 'x') {
      tokens.push(ch)
      i++
    } else {
      i++
    }
  }
  return tokens
}

function multiplyPoly(c1, c2) {
  var result = {}
  for (var k1 in c1) {
    if (!c1.hasOwnProperty(k1)) continue
    for (var k2 in c2) {
      if (!c2.hasOwnProperty(k2)) continue
      var v = c1[k1] * c2[k2]
      var deg1 = k1 === 'const' ? 0 : parseInt(k1.substring(1))
      var deg2 = k2 === 'const' ? 0 : parseInt(k2.substring(1))
      var newDeg = deg1 + deg2
      var newKey = newDeg === 0 ? 'const' : 'x' + newDeg
      result[newKey] = (result[newKey] || 0) + v
    }
  }
  return result
}

function parseFactor(tokens, pos) {
  if (pos >= tokens.length) return { coeffs: {}, pos: pos }
  var t = tokens[pos]

  if (t === '(') {
    var exprRes = parseExprRD(tokens, pos + 1)
    var endPos = exprRes.pos
    if (endPos < tokens.length && tokens[endPos] === ')') endPos++
    return { coeffs: exprRes.coeffs, pos: endPos }
  }

  if (t === 'x') {
    if (pos + 1 < tokens.length && tokens[pos + 1] === '^') {
      var power = parseInt(tokens[pos + 2])
      if (!isNaN(power) && power >= 1) {
        var obj = {}
        obj['x' + power] = 1
        return { coeffs: obj, pos: pos + 3 }
      }
    }
    return { coeffs: { x1: 1 }, pos: pos + 1 }
  }

  var num = parseFloat(t)
  if (!isNaN(num)) {
    if (pos + 1 < tokens.length && tokens[pos + 1] === 'x') {
      if (pos + 2 < tokens.length && tokens[pos + 2] === '^') {
        var varPower = parseInt(tokens[pos + 3])
        if (!isNaN(varPower) && varPower >= 1) {
          var obj3 = {}
          obj3['x' + varPower] = num
          return { coeffs: obj3, pos: pos + 4 }
        }
      }
      var obj4 = {}
      obj4['x1'] = num
      return { coeffs: obj4, pos: pos + 2 }
    }
    return { coeffs: { const: num }, pos: pos + 1 }
  }

  return { coeffs: {}, pos: pos + 1 }
}

function parseTerm(tokens, pos) {
  var res = parseFactor(tokens, pos)
  var coeffs = res.coeffs
  var i = res.pos
  while (i < tokens.length) {
    if (tokens[i] === '*' || tokens[i] === '/') {
      var op = tokens[i]
      var factorRes = parseFactor(tokens, i + 1)
      if (op === '*') {
        coeffs = multiplyPoly(coeffs, factorRes.coeffs)
      } else {
        var divisor = factorRes.coeffs.const
        if (divisor) {
          var res2 = {}
          for (var k in coeffs) res2[k] = coeffs[k] / divisor
          coeffs = res2
        }
      }
      i = factorRes.pos
    } else if (tokens[i] === '(' || tokens[i] === 'x') {
      var factorRes2 = parseFactor(tokens, i)
      coeffs = multiplyPoly(coeffs, factorRes2.coeffs)
      i = factorRes2.pos
    } else {
      break
    }
  }
  return { coeffs: coeffs, pos: i }
}

function parseExprRD(tokens, pos) {
  var sign = 1
  if (pos < tokens.length && tokens[pos] === '-') { sign = -1; pos++ }
  else if (pos < tokens.length && tokens[pos] === '+') { pos++ }

  var res = parseTerm(tokens, pos)
  var coeffs = res.coeffs
  if (sign === -1) {
    for (var key in coeffs) coeffs[key] = -coeffs[key]
  }
  var i = res.pos
  while (i < tokens.length && (tokens[i] === '+' || tokens[i] === '-')) {
    var op = tokens[i]
    var termRes = parseTerm(tokens, i + 1)
    for (var key2 in termRes.coeffs) {
      var val = termRes.coeffs[key2]
      if (op === '-') val = -val
      coeffs[key2] = (coeffs[key2] || 0) + val
    }
    i = termRes.pos
  }
  return { coeffs: coeffs, pos: i }
}

function formatNum(n) {
  var rounded = Math.round(n * 100000) / 100000
  if (Math.abs(rounded - Math.round(rounded)) < 0.000001) {
    return String(Math.round(rounded))
  }
  return String(rounded)
}

export function isPolynomialExpr(expr) {
  return isPolynomial(expr)
}

export function getDerivCoeffs(expr) {
  var tokens = tokenize(expr)
  var coeffs = parseExprRD(tokens, 0).coeffs
  var deriv = {}
  for (var key in coeffs) {
    if (key === 'const') continue
    var deg = parseInt(key.substring(1))
    var newDeg = deg - 1
    var newKey = newDeg === 0 ? 'const' : 'x' + newDeg
    deriv[newKey] = (deriv[newKey] || 0) + coeffs[key] * deg
  }
  return deriv
}

export function evalNumerical(expr, x0) {
  return numericalDerivative(expr, x0)
}

export { formatNum }

function symbolicDerivative(expr) {
  var tokens = tokenize(expr)
  var coeffs = parseExprRD(tokens, 0).coeffs

  var deriv = {}
  for (var key in coeffs) {
    if (key === 'const') continue
    var deg = parseInt(key.substring(1))
    var newDeg = deg - 1
    var newKey = newDeg === 0 ? 'const' : 'x' + newDeg
    deriv[newKey] = (deriv[newKey] || 0) + coeffs[key] * deg
  }

  var degrees = []
  for (var k in deriv) degrees.push({ key: k, val: deriv[k] })
  degrees.sort(function (a, b) {
    var da = a.key === 'const' ? 0 : parseInt(a.key.substring(1))
    var db = b.key === 'const' ? 0 : parseInt(b.key.substring(1))
    return db - da
  })

  var str = ''
  for (var i = 0; i < degrees.length; i++) {
    var coeff = degrees[i].val
    var dkey = degrees[i].key
    if (Math.abs(coeff) < 1e-9) continue

    var termStr = ''
    if (dkey === 'const') {
      termStr = formatNum(coeff)
    } else {
      var deg2 = parseInt(dkey.substring(1))
      if (Math.abs(Math.abs(coeff) - 1) < 1e-9 && deg2 > 0) {
        termStr = coeff > 0 ? '' : '-'
      } else {
        termStr = formatNum(coeff)
      }
      termStr += deg2 === 1 ? 'x' : ('x^' + deg2)
    }

    if (str === '') {
      str = termStr
    } else {
      str += coeff > 0 ? '+' + termStr : termStr
    }
  }

  return str || '0'
}

function numericalDerivative(expr, x0) {
  var h = 1e-5
  var e1 = expr.split('x').join('(' + (x0 + h) + ')')
  var e2 = expr.split('x').join('(' + (x0 - h) + ')')
  var f1 = evaluate(e1)
  var f2 = evaluate(e2)
  return (f1 - f2) / (2 * h)
}

// 主入口: 回傳求導結果字串, 拋出Error('EMPTY') / Error('PARSE_ERROR')
export function solveDerivative(rawExpr) {
  var expr = rawExpr.replace(/\s/g, '')
  if (expr.length === 0) {
    throw new Error('EMPTY')
  }
  try {
    if (isPolynomial(expr)) {
      return "f'(x)=" + symbolicDerivative(expr)
    } else {
      var val = numericalDerivative(expr, 1)
      return "f'(1)=" + formatNum(val)
    }
  } catch (e) {
    throw new Error('PARSE_ERROR')
  }
}
