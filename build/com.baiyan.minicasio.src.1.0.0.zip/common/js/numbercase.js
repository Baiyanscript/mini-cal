// numbercase.js - 阿拉伯數字轉中文財務大寫

var DIGITS = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖']
var UNITS = ['', '拾', '佰', '仟']
var BIG_UNITS = ['', '万', '亿', '万亿']

function fourDigitToChinese(numStr) {
  var result = ''
  var len = numStr.length
  var zeroFlag = false
  for (var i = 0; i < len; i++) {
    var digit = parseInt(numStr[i], 10)
    var unitIndex = len - 1 - i
    if (digit === 0) {
      zeroFlag = true
    } else {
      if (zeroFlag && result !== '') {
        result += DIGITS[0]
      }
      result += DIGITS[digit] + UNITS[unitIndex]
      zeroFlag = false
    }
  }
  return result
}

export function toChineseUppercase(input) {
  var str = String(input).trim()
  var negative = false
  if (str.charAt(0) === '-') {
    negative = true
    str = str.slice(1)
  }

  var parts = str.split('.')
  var intPart = parts[0] || '0'
  var decPart = parts[1] || ''

  intPart = intPart.replace(/^0+(?=\d)/, '')
  if (intPart === '') intPart = '0'

  var integerResult
  if (intPart === '0') {
    integerResult = DIGITS[0]
  } else {
    var groups = []
    var s = intPart
    while (s.length > 0) {
      var chunk = s.length > 4 ? s.slice(-4) : s
      s = s.length > 4 ? s.slice(0, -4) : ''
      groups.unshift(chunk)
    }
    var pieces = []
    for (var g = 0; g < groups.length; g++) {
      var chunkText = fourDigitToChinese(groups[g])
      var bigUnitIndex = groups.length - 1 - g
      if (chunkText !== '') {
        pieces.push(chunkText + BIG_UNITS[bigUnitIndex])
      }
    }
    integerResult = pieces.join('')
    if (integerResult === '') integerResult = DIGITS[0]
  }

  var result = integerResult + '元'

  if (decPart.length > 0) {
    var jiao = decPart.length >= 1 ? parseInt(decPart[0], 10) : 0
    var fen = decPart.length >= 2 ? parseInt(decPart[1], 10) : 0
    if (jiao === 0 && fen === 0) {
      result += '整'
    } else {
      if (jiao > 0) result += DIGITS[jiao] + '角'
      if (fen > 0) result += DIGITS[fen] + '分'
    }
  } else {
    result += '整'
  }

  return (negative ? '负' : '') + result
}
